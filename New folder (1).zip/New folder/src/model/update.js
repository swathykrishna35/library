// const mongoose = require('mongoose');
// mongoose.connect('mongodb://localhost:27017/library');
// const Schema = mongoose.Schema;


// // const updateSchema = new Schema({
    
// // });

// // router.put('/:id/update', );

// var update =mongoose.model('/:id/update',updateSchema);

// module.exports = update;