const express =require('express');
const adminRouter =express.Router();
const Bookdata = require('../model/Bookdata');

function router(nav){
    adminRouter.get('/',function(req,res){

        res.render('addbook',{
            nav,
            title: 'library'
        })
   
   })

   adminRouter.post('/Add',function(req,res){
     var item ={
      title: req.body.title,
      Description: req.body.Description,
       image: req.body.image
     }

    var book= Bookdata(item);
    book.save();
    res.redirect('/Ebooks');

   });
   return adminRouter;
}

module.exports = router;