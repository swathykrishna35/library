const express = require("express");

const EbooksRouter1 = express.Router();//using express.router class for book router
//called function
function router(nav){

var books=[
    { title:'The scarlet letter',
      
   desc:"The Scarlet Letter sheds light on the nineteenth century in which it was written, as Hawthorne explores his ambivalent relations with his Puritan forebears",
      img:"kid1.jpg"   // static file is accessed it should be in Public as mentioned
    },
    { title:'Just mercy',
    
    desc:"Just Mercy is an unforgettable account of an idealistic, gifted young lawyer’s coming of age, a moving window into the lives of those he has defended, and an inspiring argument for compassion in the pursuit of true justice",
    img:"kid2.jpeg"   
    },
    { title:'Double Take',
    
    desc:'An fbi thriller which takes the reader to a third world of mystery',

    img:"kid3.jpeg"   
    },
    { title:'The sun is Also a star',
    
    desc:"College-bound romantic Daniel Bae and Jamaica-born pragmatist Natasha Kingsley meet and fall for each other  over one magical day amidst the fervor and flurry of New York City",
    img:"kid4.jpeg"  
    },
    { title:'Harry potter',
    
    desc:" As Harry enters his fifth year at wizard school, Lord Voldemort’s rise has opened a rift in the wizarding world between those who believe the truth about his return, and those who prefer to believe it’s all madness and lies - just more trouble from Harry Potter",
    img:"apj1.jpg"  
    },
    { title:'Matilda',
   
    desc:"MATILDA IS A SWEET, 5-YEAR-OLD GENIUS with horrible, mean parents. Fortunately, she has a great time giving them what they deserve. But at school things are different. At school there's Miss Trunchbull: two hundred pounds of kid-hating headmistress. Giving Miss Trunchbull what she deserves will take more than a genius...it will take a superhuman genius! ",

    img:"shake1.jpg"  
    }
    // { title:'Macbeth',
    // author:'Shakespeare',
    // genre:'Tragedy',
    // desc:"Macbeth is a tragedy by William Shakespeare.It dramatises the damaging physical and psychological effects of political ambition on those who seek power for its own sake",
    // img:"shake2.jpg"  
    // }
    ]  
    
    //Method 2 
    booksRouter1.get('/',function(req,res){
        res.render("Ebook",
    {
        // nav:[{link:'/books',name:'Books'},
        // {link:'/authors',name:'Author'}],
        nav,
        title:'Library Management',
        books    // pass books array along with the response(route)
    });
    });
    // for book single page
    booksRouter1.get('/:id',function(req,res){
        const id=req.params.id;
        res.render('books',
        {
        // nav:[{link:'/books',name:'Books'},
        // {link:'/authors',name:'Author'}],
        nav,
        title:'Library',
        book:books[id]
        });
    });
    return booksRouter1;
}
    module.exports=router;

